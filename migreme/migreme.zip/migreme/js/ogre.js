jQuery(document).ready(function($) {
	$("#query").tweet({
		avatar_size: 32,
		count: 4,
		query: "gean.me",
		loading_text: "ogros trabalhando..."
	});
})

}
